# pylint: skip-file
from kafka import KafkaConsumer
from kafka import TopicPartition
from datareceiving.common import config


def print_kafka_info(consumer, topic):
    """
    打印kafka堆积信息
    """
    partitions = [TopicPartition(topic, p) for p in consumer.partitions_for_topic(topic)]
    print('start to cal offset:')

    # total
    toff = consumer.end_offsets(partitions)
    toff = [(key.partition, toff[key]) for key in toff.keys()]
    toff.sort()
    print(f'total offset: {str(toff)}')

    # current
    coff = [(x.partition, consumer.committed(x)) for x in partitions]
    coff.sort()
    print(f'current offset: {str(coff)}')

    # cal sum and left
    toff_sum = sum([x[1] for x in toff])
    cur_sum = sum([x[1] for x in coff if x[1] is not None])
    left_sum = toff_sum - cur_sum
    print(f'kafka left: {left_sum}')

def start_consumer():
    c = config.Config()
    c.load(name='data-receiving')
    host = c.config.host
    port = c.config.port
    topic = 'topic.collection'
    # 创建消费者
    consumer = KafkaConsumer(topic,
                             bootstrap_servers=f'{host}:{port}',
                             auto_offset_reset='earliest',
                             enable_auto_commit=False,
                             group_id=topic,
                             api_version=(0, 10))
    print_kafka_info(consumer, topic)

if __name__ == '__main__':
    start_consumer()