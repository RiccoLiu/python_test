import os
import shutil
import glob
from setuptools import setup, Extension
from Cython.Build import cythonize


def cythonize_and_clean_up(source_dir, exclude_files=None, exclude_dirs=None, backup_dir=None):
    if exclude_files is None:
        exclude_files = []
    if exclude_dirs is None:
        exclude_dirs = []

    # 获取所有 .py 文件
    py_files = glob.glob(f'{source_dir}/**/*.py', recursive=True)

    # 过滤掉不需要编译的文件
    files_to_cythonize = [
        f for f in py_files
        if os.path.basename(f) not in exclude_files and
           all(exc_dir not in f for exc_dir in exclude_dirs)
    ]

    # 创建扩展模块列表
    extensions = []
    for py_file in files_to_cythonize:
        module_name = os.path.splitext(py_file.replace(os.sep, '.'))[0]
        extensions.append(
            Extension(module_name, [py_file], language='c')
        )

    # 编译 .py 文件
    setup(
        name=os.path.basename(source_dir),
        ext_modules=cythonize(extensions, compiler_directives={'language_level': 3}),
        script_args=['build_ext', '--inplace']
    )

    # 备份原始 .py 文件
    if backup_dir:
        os.makedirs(backup_dir, exist_ok=True)
        for py_file in files_to_cythonize:
            try:
                # 构造新的文件路径
                new_path = py_file.replace(source_dir, backup_dir, 1)
                # 确保目标目录存在
                os.makedirs(os.path.dirname(new_path), exist_ok=True)
                # 移动 .py 文件
                if os.path.exists(py_file):
                    shutil.move(py_file, new_path)
                    print(f"Moved {py_file} to {new_path}")
                # 移动 .c 文件
                c_file = os.path.splitext(py_file)[0] + '.c'
                if os.path.exists(c_file):
                    shutil.move(c_file, new_path)
            except OSError as e:
                print(f"Error: {e.strerror}")

# 编译 maplearning 模块
cythonize_and_clean_up(
    source_dir='datareceiving',
    exclude_files=['__init__.py', 'main.py'],
    exclude_dirs=[],
    backup_dir='datareceiving_backup'
)