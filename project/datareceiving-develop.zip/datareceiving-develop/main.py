# -*- coding: UTF-8 -*-
"""A one line summary of the module or program, terminated by a period.

Leave one blank line.  The rest of this docstring should contain an
overall description of the module or program.  Optionally, it may also
contain a brief description of exported classes and functions and/or usage
examples.

Typical usage example:

foo = ClassFoo()
bar = foo.FunctionBar()
"""
from datareceiving.common import commands
from datareceiving.common import config


def app_echo():
    name = config.Config().config.app.name
    version = config.Config().config.app.version
    print(f'{name} {version}')


if __name__ == '__main__':
    ################################################
    app_echo()
    commands.register_commands()
