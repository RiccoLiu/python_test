#!/bin/bash

if [ $# != 3 ] ;  then
echo "$0 <image_name> <image_tag>"
echo "eg:"
echo "  sh $0 datareceiving 2022091301"
exit 1
fi

root_path="/mxdata"
local_dir=`echo $1`
image_name=`echo $2`
image_tag=`echo $3`

docker_arg='run -it -v '${root_path}':/usr/datareceiving/sample/mxdata -e ENV_FOR_DYNACONF=development --rm '${image_name}':'${image_tag}

docker ${docker_arg} python main.py data-receiving

