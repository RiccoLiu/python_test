# -*- coding: UTF-8 -*-
"""
数据导入模块入口.
1.定义命令函数.
2.实现DataIngestion主类
# pylint: disable=useless-super-delegation
"""
import shutil
import threading

import click
import os
import gzip
import hashlib
import time

from apscheduler.schedulers.background import BackgroundScheduler
from google.protobuf import message as _message
import glob
import zipfile

from Crypto.Cipher import AES
from datetime import datetime

from kafka import KafkaConsumer
from kafka import TopicPartition

from datareceiving.common import config
from loguru import logger
from datareceiving.core.storage import s3_api
from datareceiving.core.business.slam_structure import DataCollection_V6_7_pb2 as data_collection_v6_pb2
from datareceiving.core.business.datareceiving import producer
import json

lock = threading.Lock()


class DataReceiving(object):
    """数据接收主类.

    DataReceiving实现从kafka服务器接收车端上传的protobuf数据

    """

    def __init__(self, host=None, topic=None):
        super().__init__()
        self.host = host
        self.topic = topic
        self._data = []
        self.key_path = None
        self.precision1 = 100000000
        self.precision2 = 1
        self.max_x = 135.083333
        self.min_x = 73.55
        self.max_y = 53.55
        self.min_y = 3.85
        self.max_z = 8844450
        self.min_z = -154320
        self.path_list = set()

    @staticmethod
    @click.command()
    @click.option('-t', '--topic', type=str, help='topic')
    def data_receiving(topic):
        # 读取配置  读取data-receiving.yaml
        config.Config().load('data-receiving')
        host = config.Config().config.host
        port = config.Config().config.port

        # 根据参数启动
        consumer_instance = DataReceiving(host=host + ':' + port, topic=topic)
        # # 接收线程
        consumer_instance.receive()

    def md5_check(self, key_md5, msg_value):
        """md5校验
        Args:
            msg_key_list: kafka消息中的key切分成列表
            msg_value: kafka消息中的value
        Returns:
            True or False 校验成功or失败
        """
        md = hashlib.md5()
        md.update(msg_value)
        value_md5 = md.hexdigest()

        return key_md5 == value_md5

    def decompress(self, msg_value):
        """解压

        Args:
            msg_value: 需要解压的数据
        Returns:
            解压后的数据
        """
        # 压缩文件前两个字节为1f 8b
        if len(msg_value) < 2:
            return None
        if msg_value[:2] == b'\x1f\x8b':
            try:
                data_decom = gzip.decompress(msg_value)
            except EOFError:
                return None
        else:
            data_decom = msg_value
        return data_decom

    def unpad_pkcs7(self, data):
        """去除填充
        padding pkcs7: 如果数据大小不是16字节的倍数，最后一组数据用缺失数据大小补充完整
        Args:
            data: 需要去除填充的数据
        Returns:
            None : 无效数据，返回False
            data : 去除填充后的数据
        """
        data_len = len(data)
        if data_len == 0 or data_len % 16 != 0:
            return None
        last_one = data[data_len - 1:]
        invalid_len = ord(last_one)
        if 0 < invalid_len <= 16:
            return data[:-invalid_len]
        else:
            return None

    def decrypt(self, msg_headers, mag_value):
        """解密
        ECB模式各分组加密独立，不依赖于上一分组
        """
        # aes_key = config.Config().config.aes.key  # .secret.common.yaml 文件中， 当前这个参数暂未启用，202306051020
        for msg_header in msg_headers:
            if len(msg_header) != 2:
                continue
            if msg_header[0] != 'dataKey':
                continue
            cipher = AES.new(msg_header[1], AES.MODE_ECB)
            # 若传入数据解密出错，返回None
            try:
                decrypt_result = cipher.decrypt(mag_value)
            except (TypeError, ValueError):
                return None
            return self.unpad_pkcs7(decrypt_result)
        return None

    def msg_check(self, msg_key, msg_value):
        """消息检查
        检查消息key和value是否为空
        """
        if msg_key is None or msg_value is None:
            return False
        return True

    def parse_msg_value(self, data, collection_time):
        data_collection = data_collection_v6_pb2.DataCollectInfo()
        try:
            data_collection.ParseFromString(data)
        except (_message.DecodeError, IOError):
            return None
        else:
            if data_collection.data_type == data_collection_v6_pb2.TASK_DATA:
                task_results = data_collection_v6_pb2.TaskData()
                task_results.ParseFromString(data_collection.collect_data)
                image_info = data_collection_v6_pb2.ImageInfo()
                if task_results.image != image_info:
                    task_id = task_results.image.task_id
                    data_type = 'picture'
                    picture = task_results.image.data_image
                    angle = task_results.image.angle
                    m_code = task_results.image.geo_point.mcode
                    coordinate = self.convert_code_to_geo(m_code)
                    if task_id == image_info.task_id:
                        return None
                    return task_id, data_type, picture, angle, coordinate
                # sensor_info = data_collection_v6_pb2.SensorInfo
                # if task_results.sensor != sensor_info:
                #     task_id = task_results.sensor.task_id
                #     data_type = 'sensor'
                #     if task_id == sensor_info.task_id:
                #         return None
                #     return task_id, data_type
                logger.info(f'Notaskdata. {collection_time}')
                return None
            logger.info(f'TaskDataTypeError. {collection_time}')
            return None

    def parse_msg_header(self, msg_key):

        json_object = json.loads(msg_key)
        key_car_id = json_object['vin']
        key_timestamp = json_object['timestamp']
        key_type = json_object['type']
        key_model_id = json_object['modelId']
        key_md5 = json_object['verification']

        if key_model_id == 0:
            sub_dir = 'c385'
        elif key_model_id == 1:
            sub_dir = 'sda'
        else:
            sub_dir = 'other'
        if key_type == data_collection_v6_pb2.LOCATION_INFO:
            task_type = 'basic'
            data_type = 'trajectory'
        elif key_type == data_collection_v6_pb2.SEMANTIC_MAP:
            task_type = 'basic'
            data_type = 'semantic'
        elif key_type == data_collection_v6_pb2.IDENTIFY_OBJECT:
            task_type = 'basic'
            data_type = 'identify'
        elif key_type == data_collection_v6_pb2.TASK_DATA:
            task_type = 'task'
            sub_dir = 'task_id'
            data_type = 'task_data_type'
        else:
            return None

        return (key_md5, sub_dir, data_type, key_car_id, task_type, key_timestamp)

    @classmethod
    def log(cls, timestamp, msg, car_type=None, data_type=None):
        try:
            timestamp = int(timestamp) / 1000.0
        except ValueError:
            return
        date_array = datetime.fromtimestamp(timestamp)
        final_time = date_array.strftime('%Y-%m-%d %H:%M:%S')
        if car_type is None and data_type is None:
            logger.info(f'kafka_time:[{final_time}] {msg} ')
        else:
            logger.info(f'kafka_time:[{final_time}] {msg} car_type:{car_type} data_type:{data_type}')

    # 计算文件size
    def calculate_folder_size(self, folder_path):
        total_size = 0
        for dirpath, dirnames, filenames in os.walk(folder_path):
            for file in filenames:
                file_path = os.path.join(dirpath, file)
                # 跳过如果它是一个符号链接
                if not os.path.islink(file_path):
                    total_size += os.path.getsize(file_path)
        return total_size

    # 打包文件
    def pack_directory_to_zip(self, directory_path, zip_filename):
        out_path = os.path.join(directory_path, zip_filename)
        # 创建一个ZipFile对象，准备写入ZIP文件
        with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # 遍历目录下的所有文件和子目录
            for root, dirs, files in os.walk(directory_path):
                # 遍历文件
                for file in files:
                    if os.path.splitext(file)[1] == '.zip':
                        continue
                    file_path = os.path.join(root, file)
                    # 获取文件相对于目录路径的相对路径
                    arcname = os.path.relpath(file_path, directory_path)
                    # 将文件添加到ZIP归档中
                    zipf.write(file_path, arcname)

    # 删除文件
    def delete_files_in_directory(self, directory_path, pattern='*'):
        if os.path.isdir(directory_path):
            shutil.rmtree(directory_path)
        elif os.path.isfile(directory_path):
            os.remove(directory_path)

    def get_oldest_file_time(self, directory_path):
        timestamp = time.time()
        oldest_time = None
        # 使用glob模块获取目录下的所有文件
        for filename in glob.glob(os.path.join(directory_path, '*')):
            if os.path.isfile(filename):  # 确保是一个文件而不是目录
                file_time = os.path.getmtime(filename)
                if oldest_time is None or file_time < oldest_time:
                    oldest_time = file_time
        if oldest_time is None:
            return 0
        return int((timestamp - oldest_time) / 60)

    def zip_to_upload(self):
        while True:
            time.sleep(120)
            lock.acquire()
            # 初始化路径set
            del_set = set()
            for output_path in self.path_list:
                # #
                file_time = self.get_oldest_file_time(output_path)
                # # 统计文件个数
                count_file = len(
                    [f for f in os.listdir(output_path) if os.path.isfile(os.path.join(output_path, f))])
                total_size = self.calculate_folder_size(output_path)
                if count_file >= 1000 or total_size >= 32212254720 or file_time >= 5:
                    if count_file >= 1:
                        file_names = [f for f in os.listdir(output_path) if os.path.isfile(os.path.join(output_path, f))]
                        first_name = file_names[0]
                        first_name = first_name.split(".")[0]
                        last_file_name = file_names[-1]
                        last_file_name = last_file_name.split(".")[0]
                        zip_filename = os.path.basename(
                            output_path) + "_" + first_name + "-" + last_file_name + ".zip"
                        # 上传文件
                        self.pack_directory_to_zip(output_path, zip_filename)
                        self.key_path = output_path.replace(config.Config().config.output_path + '/', '')
                        if self.upload(output_path, zip_filename):
                            self.delete_files_in_directory(output_path)
                            del_set.add(output_path)
                        else:
                            self.delete_files_in_directory(os.path.join(output_path, zip_filename))
            for del_path in del_set:
                self.path_list.remove(del_path)
            lock.release()

    # 接收方法
    def receive(self):
        # 创建消费者
        consumer = KafkaConsumer(self.topic,
                                 bootstrap_servers=self.host,
                                 auto_offset_reset='latest',
                                 enable_auto_commit=False,
                                 group_id=self.topic,
                                 max_poll_interval_ms=3600000,
                                 api_version=(2, 10))
        if self.topic == 'sda-CA.collection':
            producer_ = producer.Producer()  # 发送的需求待定 接受数据的时候要发一些消息，但是是特定的数据
        print(f'bootstrap_servers: {self.host}')
        print(f'prepare receive topic: {self.topic}')
        # if consumer.partitions_for_topic(self.topic) is not None:
        #     self.get_kafka_info(consumer)
        scheduler = BackgroundScheduler()
        scheduler.add_job(self.zip_to_upload, 'interval', seconds=300, max_instances=1)
        scheduler.start()
        # 消费者信息
        for msg in consumer:
            lock.acquire()
            try:
                self.log(msg.timestamp, f'[begin receive] msg.timestamp: {msg.timestamp}, msg.partition: {msg.partition}')
                if not self.msg_check(msg.key, msg.value):
                    self.log(msg.timestamp, 'msg check failed')
                    consumer.commit()
                    continue
                self.log(msg.timestamp, f'msg.value:{len(msg.value)}bytes')
                parse_key_result = self.parse_msg_header(msg.key)
                if parse_key_result is None:
                    self.log(msg.timestamp, f'msg.key check failed. msg.key is {msg.key}')
                    consumer.commit()
                    continue
                key_md5, sub_dir, data_type, key_car_id, task_type, key_timestamp = parse_key_result
                # md5校验
                if not self.md5_check(key_md5, msg.value):
                    self.log(msg.timestamp, f'md5 check failed. key_timestamp is {key_timestamp}', sub_dir, data_type)
                    consumer.commit()
                    continue
                # 解密
                msg_value = self.decrypt(msg.headers, msg.value)
                if msg_value is None:
                    self.log(msg.timestamp, f'decrypt failed. key_timestamp is {key_timestamp}', sub_dir, data_type)
                    consumer.commit()
                    continue
                # 解压缩
                out = self.decompress(msg_value)
                if out is None:
                    self.log(msg.timestamp, f'decompress failed. key_timestamp is {key_timestamp}', sub_dir, data_type)
                    consumer.commit()
                    continue
                # 数据采集时间信息，当作文件名
                collection_time = key_timestamp
                if not self.is_valid(out):
                    self.log(msg.timestamp, f'out check failed. key_timestamp is {key_timestamp}', sub_dir, data_type)
                    consumer.commit()
                    continue
                if task_type == 'task':
                    parse_value_result = self.parse_msg_value(out, collection_time)
                    if parse_value_result is None:
                        self.log(msg.timestamp, f'parse value failed. key_timestamp is {key_timestamp}', sub_dir)
                        consumer.commit()
                        continue
                    sub_dir, data_type, picture, angle, coordinate = parse_value_result
                    output_path = self.get_output_path(sub_dir, data_type, key_car_id, task_type)
                    # 保存文件
                    image_name = self.save_image_file(output_path, picture, angle, coordinate, collection_time)
                    # 上传文件
                    if not self.upload_image(output_path, image_name):
                        self.log(msg.timestamp, f'upload failed. key_timestamp is {key_timestamp}', sub_dir, data_type)
                        continue
                    # 手动commit
                    consumer.commit()
                    self.log(msg.timestamp, f'[upload success]. key_timestamp is {key_timestamp}', sub_dir, data_type)
                    continue
                # 加入数据处理队列
                self._data.append([collection_time, out])
                output_path = self.get_output_path(sub_dir, data_type, key_car_id, task_type)
                # 保存文件
                file_name = self.save_file(output_path)
                self.path_list.add(output_path)

                # 手动commit
                consumer.commit()
                self.log(msg.timestamp, f'[upload success]. key_timestamp is {key_timestamp}', sub_dir, data_type)
                if self.topic == 'sda-CA.collection':
                    producer_data = {}
                    producer_data.setdefault('eventName', 's3:ObjectAccessed:Put')
                    producer_data.setdefault('size', len(msg.value))
                    upload_time = int(round(time.time() * 1000))
                    producer_data.setdefault('eventTime', upload_time)
                    key = os.path.join(config.Config().config.outputprefix.bucket,  # data-receiving.yaml  配置文件中
                                       config.Config().config.outputprefix.kafka, self.key_path, file_name)
                    key = key.replace('\\', '/')
                    producer_data.setdefault('key', key)
                    producer_.send_producer(producer_data)
            except Exception as e:
                e.__str__()
            finally:
                lock.release()


    def get_kafka_info(self, consumer):
        """
        打印kafka堆积信息
        """
        partitions = [TopicPartition(self.topic, p) for p in consumer.partitions_for_topic(self.topic)]
        print('start to cal offset:')

        # total
        toff = consumer.end_offsets(partitions)
        toff = [(key.partition, toff[key]) for key in toff.keys()]
        toff.sort()
        print(f'total offset: {str(toff)}')

        # current
        coff = [(x.partition, consumer.committed(x)) for x in partitions]
        coff.sort()
        print(f'current offset: {str(coff)}')

        # cal sum and left
        toff_sum = sum([x[1] for x in toff])
        cur_sum = sum([x[1] for x in coff if x[1] is not None])
        left_sum = toff_sum - cur_sum
        print(f'kafka left: {left_sum}')

    def get_output_path(self, sub_dir, data_type, car_id, task_type):
        """
        获取输出路径
        获取 存储在s3上的 .record文件路径
        """
        output_folder = config.Config().config.output_path  # data-receiving.yaml 配置文件
        if self.topic == 'sda-CA.collection':
            self.key_path = task_type + '/' + 'sda-CA' + \
                            '/' + (str(datetime.today())).split(' ', maxsplit=1)[0] + '/' + car_id + '/' + data_type
            output_path = output_folder + '/' + task_type + '/' + 'sda-CA' + \
                          '/' + (str(datetime.today())).split(' ', maxsplit=1)[0] + '/' + car_id + '/' + data_type
        else:
            self.key_path = task_type + '/' + str(sub_dir) + \
                            '/' + (str(datetime.today())).split(' ', maxsplit=1)[0] + '/' + car_id + '/' + data_type
            output_path = output_folder + '/' + task_type + '/' + str(sub_dir) + \
                          '/' + (str(datetime.today())).split(' ', maxsplit=1)[0] + '/' + car_id + '/' + data_type
        return output_path

    def save_image_file(self, output_path, picture, angle, coordinate, timestamp):
        if not os.path.exists(output_path):
            os.makedirs(output_path)
        picture_file_name = ('data_picture_' + str(timestamp) + '.JPEG')
        info_file_name = ('data_picture_' + str(timestamp) + '.yaml')
        picture_file_path = os.path.join(output_path, picture_file_name)
        info_file_path = os.path.join(output_path, info_file_name)
        with open(picture_file_path, 'ab') as f:
            f.write(picture)
        with open(info_file_path, 'a', encoding='utf-8') as f:
            f.write(f'geo_point: {coordinate}\n')
        with open(info_file_path, 'a', encoding='utf-8') as f:
            f.write(f'angle: {angle}')
        return picture_file_name, info_file_name

    def save_file(self, output_path):
        """
        将pbf保存成本地文件
        """
        if not os.path.exists(output_path):
            os.makedirs(output_path)
        [collection_time, values] = self._data.pop()
        file_name = (str(collection_time) + '.record')
        file_path = os.path.join(output_path, file_name)
        with open(file_path, 'ab') as f:
            f.write(values)
        return file_name

    def clear_local(self, filepath):
        """
        删除本地文件
        """
        if os.path.exists(filepath):
            os.remove(filepath)

    def upload(self, output_path, file_name):
        """
        pbf上传s3服务器
        """
        upload_prefix = config.Config().config.outputprefix  # data-receiving.yaml 配置文件
        # 上传kafka数据
        filepath = os.path.join(output_path, file_name)
        filepath = filepath.replace('\\', '/')
        key = os.path.join(upload_prefix.kafka, self.key_path, file_name)
        key = key.replace('\\', '/')
        result = s3_api.S3Client().upload_file(filepath, upload_prefix.bucket, key)
        self.clear_local(filepath)
        return result

    def upload_image(self, output_path, file_name):
        """
        图片信息上传s3服务器
        """
        upload_prefix = config.Config().config.outputprefix  # data-receiving.yaml  上传图像功能暂时未启用
        for name in file_name:
            filepath = os.path.join(output_path, name)
            filepath = filepath.replace('\\', '/')
            key = os.path.join(upload_prefix.kafka, self.key_path, name)
            key = key.replace('\\', '/')
            result = s3_api.S3Client().upload_file(filepath, upload_prefix.bucket, key)
            self.clear_local(filepath)
            if not result:
                return result
        return result

    def geo_range_check(self, x, y, z):
        if self.max_x < x or x < self.min_x:
            return False
        if self.max_y < y or y < self.min_y:
            return False
        if self.max_z < z or z < self.min_z:
            return False
        return True

    def xcode_to_bit32(self, t):
        if '2' <= t <= '9':
            return ord(t) - ord('2')
        if 'A' <= t <= 'H':
            return ord(t) - ord('A') + 8
        if 'J' <= t <= 'N':
            return ord(t) - ord('J') + 16
        if 'P' <= t <= 'Z':
            return ord(t) - ord('P') + 21

        return 255

    def convert_code_to_geo(self, m_code):
        if not m_code or 18 != len(m_code):
            return False
        x = ((((self.xcode_to_bit32(m_code[4]) & 0x01) << 2) | (
                self.xcode_to_bit32(m_code[5]) >> 3)) * 32 * 32 * 32 * 32 * 32 * 32) + \
            ((self.xcode_to_bit32(m_code[12])) * 32 * 32 * 32 * 32 * 32) + \
            ((self.xcode_to_bit32(m_code[13])) * 32 * 32 * 32 * 32) + \
            ((self.xcode_to_bit32(m_code[14])) * 32 * 32 * 32) + \
            ((self.xcode_to_bit32(m_code[15])) * 32 * 32) + \
            ((self.xcode_to_bit32(m_code[16])) * 32) + \
            (self.xcode_to_bit32(m_code[17]))
        y = (self.xcode_to_bit32(m_code[5]) & 0x07) * 32 * 32 * 32 * 32 * 32 * 32 + \
            (self.xcode_to_bit32(m_code[6])) * 32 * 32 * 32 * 32 * 32 + \
            (self.xcode_to_bit32(m_code[7])) * 32 * 32 * 32 * 32 + \
            (self.xcode_to_bit32(m_code[8])) * 32 * 32 * 32 + \
            (self.xcode_to_bit32(m_code[9])) * 32 * 32 + \
            (self.xcode_to_bit32(m_code[10])) * 32 + \
            (self.xcode_to_bit32(m_code[11]))
        z = (self.xcode_to_bit32(m_code[0])) * 32 * 32 * 32 * 32 * 32 + (
            self.xcode_to_bit32(m_code[1])) * 32 * 32 * 32 * 32 + (
                self.xcode_to_bit32(m_code[2])) * 32 * 32 * 32 + (
                self.xcode_to_bit32(m_code[3])) * 32 * 32 + (self.xcode_to_bit32(m_code[4])) * 32 + (
                self.xcode_to_bit32(m_code[5]))

        z >>= 6
        x = x / self.precision1 + self.min_x
        y = y / self.precision1 + self.min_y
        z = z / self.precision2 + self.min_z
        if self.geo_range_check(x, y, z):
            return x, y, z
        else:
            return None

    def is_valid(self, out):
        data_collection = data_collection_v6_pb2.DataCollectInfo()
        try:
            data_collection.ParseFromString(out)
        except (_message.DecodeError, IOError):
            return None
        else:
            if not data_collection.collect_data:
                return False
        return True
