from kafka import KafkaProducer
from kafka.errors import kafka_errors
from datareceiving.common import config
from loguru import logger
import json
import fuuid
import time


class Producer(object):

    def __init__(self):
        super().__init__()
        self.host = config.Config().config.host  # data-receiving.yaml
        self.port = config.Config().config.port
        self.topic = config.Config().config.producer_topic
        self.producer = KafkaProducer(bootstrap_servers=f'{self.host}:{self.port}',
                                      value_serializer=lambda m: json.dumps(m).encode('ascii'),
                                      api_version=(2, 10))

    def send_producer(self, data):
        """
        同步发送 数据
        :param data:  发送数据
        :return:
        """
        capture_data = {}
        capture_data.setdefault('id', str(fuuid.fuuid()))
        capture_data.setdefault('topic', self.topic)
        capture_data.setdefault('producer', 'data-receiving')
        capture_data.setdefault('created_at', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())))
        capture_data.setdefault('content_type', 'application/json')
        capture_data.setdefault('data', data)
        try:
            future = self.producer.send(self.topic, capture_data)
            result = future.get(timeout=10)
            topic, partition, offset = result.topic, result.partition, result.offset
            print("topic:{} partition:{} offset:{}".format(topic, partition, offset))
        except BaseException as e:
            logger.error(f'send_producer_error{e}')
