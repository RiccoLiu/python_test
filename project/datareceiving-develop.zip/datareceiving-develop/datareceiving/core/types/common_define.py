# -*- coding: UTF-8 -*-
"""A one line summary of the module or program, terminated by a period.

Leave one blank line.  The rest of this docstring should contain an
overall description of the module or program.  Optionally, it may also
contain a brief description of exported classes and functions and/or usage
examples.

Typical usage example:

foo = ClassFoo()
bar = foo.FunctionBar()
"""
from enum import Enum


class ObjectType(Enum):
    """Summary of class here.

    Longer class information....
    Longer class information....

    Attributes:
        likes_spam: A boolean indicating if we like SPAM or not.
        eggs: An integer count of the eggs we have laid.
    """
    OBJECT_TYPE_UNKNOWN = 1000
    GROUND_LANE = 1
    GROUND_MARK = 2
    TRAFFIC_SIGN = 3
    TRAFFIC_LIGHT = 4
    ROAD_SIDE_STRIP = 5
    ROAD_SIDE_POLE = 6
    TRAFFIC_CONE = 7
    TOP_GANTRY = 8
    DRIVING_RANGE = 9


class ObjectColorType(Enum):
    """Summary of class here.

    Longer class information....
    Longer class information....

    Attributes:
        likes_spam: A boolean indicating if we like SPAM or not.
        eggs: An integer count of the eggs we have laid.
    """
    COLOR_TYPE_UNKNOWN = 0
    WHITE = 1
    YELLOW = 2
    ORANGE = 3
    BLUE = 4
    GREEN = 5


class ObjectLaneType(Enum):
    """Summary of class here.

    Longer class information....
    Longer class information....

    Attributes:
        likes_spam: A boolean indicating if we like SPAM or not.
        eggs: An integer count of the eggs we have laid.
    """
    LANE_TYPE_UNKNOWN = 1000
    DOTTED_LINE = 1
    THIN_DASHED_LINE = 2
    THICK_DASHED_LINE = 3
    SINGLE_DASHED_LINE = 4
    SINGLE_SOLID_LINE = 5
    DOUBLE_DASHED_LINE = 6
    DOUBLE_SOLID_LINE = 7
    DASHED_LEFT_SOLID_RIGHT = 8
    SOLID_LEFT_DASHED_RIGHT = 9
    EDGE_LINE = 10
    STOP_LINE = 101
    SIDE_WALK = 102
    SPEED_BUMPS = 103
    SLOWDOWN_YIELD_SIGN = 104
    STOP_YIELD_SIGN = 105
    CHECK_FOLLOWING_DISTANCE = 106
    DIVERSION_LINE = 107
    CENTER_CIRCLE = 108
    NETS_LINE = 109
    P_NO_RETURN_MARK = 110
    P_NO_TURN_MARK = 111
    SPEED_HUMP_LINE = 112
    SLOW_DOWN_LINE = 113
    PARKING_SPACE_LINE = 114
    ROAD_LINE = 401
    DRIVABLE_AREA = 402
    PEDESTRIAN_AREA = 403


class ObjectLaneMarkType(Enum):
    """Summary of class here.

    Longer class information....
    Longer class information....

    Attributes:
        likes_spam: A boolean indicating if we like SPAM or not.
        eggs: An integer count of the eggs we have laid.
    """
    LANE_MARK_TYPE_UNKNOWN = 1000
    ARROW_FORWARD = 1
    ARROW_LEFT = 2
    ARROW_RIGHT = 3
    ARROW_LEFT_AND_FORWARD = 4
    ARROW_RIGHT_AND_FORWARD = 5
    ARROW_LEFT_AND_RIGHT = 6
    ARROW_FRONT_LEFT = 7
    ARROW_FRONT_RIGHT = 8
    ARROW_U_TURN_AND_FORWARD = 9
    ARROW_U_TURN_AND_LEFT = 10
    ARROW_LEFT_U_TURN = 11
    ARROW_RIGHT_U_TURN = 12
    CROSS_WALK_NOTICE = 13
    BICYCLE_MARK = 14
    TEXT = 15
    ARROW_MERGE_LEFT = 16
    ARROW_MERGE_RIGHT = 17
    SPEED_LIMIT_LOW = 18
    SPEED_LIMIT_HIGH = 19
    ARROW_NO_LEFT_TURN = 20
    ARROW_NO_RIGHT_TURN = 21
    ARROW_NO_UTURN = 22
    ARROW_NO_LEFT_AND_RIGHT = 23
    ARROW_NOU_TURN_AND_LEFT = 24
    ARROW_NOU_TURN_AND_RIGHT = 25
    ARROW_LEFT_AND_FORWARD_AND_RIGHT = 26


class ObjectTrafficSignType(Enum):
    """Summary of class here.

    Longer class information....
    Longer class information....

    Attributes:
        likes_spam: A boolean indicating if we like SPAM or not.
        eggs: An integer count of the eggs we have laid.
    """
    TRAFFIC_SIGN_TYPE_UNKNOWNN = 1000
    W_MOUNT_LEFT = 101
    W_MOUNT_RIGHT = 102
    W_VILLAGE = 103
    W_DAM_RIGHT = 104
    W_DAM_LEFT = 105
    WT_SHAP = 106
    W_FERRY = 107
    WLR_NARROW = 108
    W_LEFT_FALLING = 109
    WRL_TURN = 110
    WLR_TURN = 111
    W_FORD = 112
    W_CROSS_INTERSECTION = 113
    W_INTERSECTION = 114
    WY_INTERSECTION_LOWERLEFT = 115
    WY_INTERSECTION_LOWERRIGHT = 116
    WY_INTERSECTION_UPPERLEFT = 117
    W_LEFT_NARROW = 118
    WT_INTERSECTION_UPPERRIGHT = 119
    WT_INTERSECTION = 120
    WT_INTERSECTION_LEFT = 121
    WT_INTERSECTION_RIGHT = 122
    W_CIRCLE_INTERSECTION = 123
    W_CONTINUOUS_TURN = 124
    W_CONTINUOUS_DOWN = 125
    W_UNEVEN_ROAD_SURFACE = 126
    W_RAIN = 127
    W_LOW_LYING = 128
    W_BUMP = 129
    W_SLOW = 130
    W_UP = 131
    W_WORKING = 132
    W_CROSS = 133
    W_ACCIDENT_PRONE = 134
    W_TWO_WAY = 135
    W_ANIMAL = 136
    W_TUNNEL = 137
    W_TUNNEL_HEADLIGHT = 138
    W_HUMP_BRIDGE = 139
    W_RAILWAY = 140
    W_DOWN = 141
    W_RIGHT_TURN = 142
    W_LEFT_TURN = 143
    W_SLIP = 144
    W_TRAFFIC_LIGHT = 145
    W_GUARDED_RAILWAY = 146
    W_RIGHT_NARROW = 147
    W_DETOUR_RIGHT = 148
    W_NARROW_BRIDGE = 149
    W_KEEP_DISTANCE = 150
    W_BAD_WEATHER = 151
    W_DISABLED = 152
    W_TIDAL = 153
    W_FOG = 154
    W_CHILDREN = 155
    W_CYCLE = 156
    W_PEDESTRAIN = 157
    W_MERGE_LEFT = 158
    W_MERGE_RIGHT = 159
    W_SIDE_WIND = 160
    W_ICE = 161
    W_RIGHT_FALLING = 162
    W_DANGER = 163
    W_DOMESTIC = 164
    W_DETOUR_LEFT = 165
    W_DETOUR_AROUND = 166
    W_VEHICLE_QUEUE = 167
    P_NO_PASSING = 201
    P_NO_ANIMAL_VEHICLE = 202
    P_NO_BUS = 203
    P_NO_ELECTRIC_TRICYCLES = 204
    P_NO_RETURN = 205
    P_NO_NON_MOTOR = 206
    P_NO_TRUCK = 226
    P_NO_TRAILER = 208
    P_NO_HUMAN = 209
    P_NO_MOTOR = 210
    P_NO_HORNING = 211
    P_NO_MOTORCYCLE = 212
    P_BOTH_VEHICLE = 213
    P_NO_FORWARD = 214
    P_NO_HUMAN_VEHICLE = 215
    P_NO_HUMAN_CARGO_TRIANGLE = 216
    P_NO_HUMAN_PASSENGER_TRIANGLE = 217
    P_NO_TRACTOR = 218
    P_NO_RIGHT_TURN = 219
    P_NO_LEFT_RIGHT_TURN = 220
    P_NO_FORWARD_RIGHT = 221
    P_NO_TRICYCLE_AND_LOW_SPEED_TRUCK = 222
    P_NO_LEFT_TURN = 223
    P_PASSENGER_CAR_RIGHT_TURN = 224
    P_NO_CAR = 225
    P_NO_DANGEROUS = 227
    P_NO_FORWARD_LEFT = 228
    P_QUALITY_LIM = 229
    P_WEIGHT_LIMWHEEL = 230
    P_CUSTOM = 231
    P_PARKING_CHECK = 232
    P_NO_PARKING = 233
    P_NO_LONG_PARKING = 234
    P_SPEED_LIM = 235
    P_SPEED_LIM_REV = 236
    P_HEIGHT_LIM = 237
    P_WIDTH_LIM = 238
    P_STOP_FOR = 239
    P_SLOW_FOR = 240
    P_NOWAY = 241
    P_GIVE_WAY = 242
    P_NO_ENTRY = 243
    P_NO_PASSING_REV = 244
    I_WALK = 301
    I_NON_MOTORS = 302
    I_CIRCLE = 303
    I_MOTORS = 328
    I_RIGHT = 305
    I_LEFT = 306
    I_FORWARD_RIGHT_STEREO = 307
    I_FORWARD_LEFT_STEREO = 308
    I_HONK = 309
    I_RIGHT_TURN = 310
    I_LEFT_RIGHT = 311
    I_LEFT_TURN = 312
    I_FORWARD = 313
    I_FORWARD_RIGHT = 314
    I_FORWARD_LEFT = 315
    I_ONE_WAY_LEFT = 316
    I_ONE_WAY_RIGHT = 317
    I_PRIORITY_AT_JUNCTION = 318
    I_PRIORITY_AT_MEETING = 319
    IARROWRIGHT = 320
    IARROWLEFT = 321
    IARROWFORWARD = 322
    IARROWRIGHTANDFORWARD = 323
    IARROWLEFTANDFORWARD = 324
    IUTURN = 325
    IUTURNANDLEFT = 326
    I_BUS_LANE = 327
    I_BICYCLE = 329
    I_BUS_RAPID_TRANSIT_LANE = 330
    I_MULTI_OCCUPANT_VEHICLE_LANE = 331
    I_PARKING_SLOT = 332
    IARROWUTURN = 333
    ISPEEDLIMITLOW = 334
    I_PEDESTRIAN_CROSS = 335
    T_DISTANCE = 501
    T_DIRECTION = 502
    TINFORMATIONDESK = 503
    T_ON_FOOT = 504
    T_CABLEWAY = 505
    T_CAMPSITE = 506
    T_CAMPFIRE = 507
    T_PLAYGROUND = 508
    T_RIDING = 509
    T_GO_FISHING = 510
    T_GOLF = 511
    T_DIVING = 512
    T_SWIMMING = 513
    T_ROWING = 514
    T_WINTER_TOURIST_AREA = 515
    T_SKIING = 516
    T_SKATING = 517
    N_NO_DRUNK_DRIVING_SIGN = 601
    N_NO_LITTERING_SIGN = 602
    N_SLOW_DOWN_SIGN_AT_SHARP_TURN = 603
    N_SHARP_BEND_DOWNHILL_SIGN = 604
    N_SEAT_BELT_SIGN = 605
    N_LARGE_VEHICLES_KEEP_RIGHT = 606
    N_DISABLE_MOBILE_PHONE_WHILE_DRIVING = 607
    N_SCHOOL_BUS_STOP = 608
    A_TIME_FRAME = 801
    A_EXCEPT_FOR_BUSES = 802
    A_TRUCKSTRACTORS = 803
    A_VEHICLE = 804
    A_TRUCK = 805
    A_PRIVATE_EXCLUSIVE = 806
    A_DRIVING_DIRECTION_SIGN = 807
    A_200_M_FORWARD = 808
    A_100_M_TO_THE_LEFT = 809
    A_LEFT_AND_RIGHT_50_M = 810
    A_100_M_TO_THE_RIGHT = 811
    A_IN_AN_AREA = 812
    A_200_M_AWAY_FROM_A_PLACE = 813
    A_SCHOOL = 814
    A_CUSTOMS = 815
    A_ACCIDENT = 816
    A_LANDSLIDE = 817
    A_DRIVING_ROUTE_OF_COACH_CAR = 818
    A_DRIVING_TEST_ROUTE = 819
    A_SCHOOL_BUS_STOP = 820
    A_COMBINED_ASSISTANCE = 821


class ObjectTrafficLightType(Enum):
    """Summary of class here.

    Longer class information....
    Longer class information....

    Attributes:
        likes_spam: A boolean indicating if we like SPAM or not.
        eggs: An integer count of the eggs we have laid.
    """
    TRAFFIC_LIGHT_TYPE_UNKNOWN = 1000
    LAMP_MOTOR = 1
    LAMP_NOR_MOTOR = 2
    LAMP_LANE_TRAFFIC = 5
    LAMP_PEDESTRIAN_CROSSING = 4
    LAMP_DIRECTION_INDICATOR = 6
    LAMP_FLASHING_WARNING = 7
    LAMP_CROSSING = 8
    LAMP_TURN = 9
    LAMP_COUNTDOWN_LIGHT = 10


class ObjectFenceType(Enum):
    """Summary of class here.

    Longer class information....
    Longer class information....

    Attributes:
        likes_spam: A boolean indicating if we like SPAM or not.
        eggs: An integer count of the eggs we have laid.
    """
    FENCE_TYPE_UNKNOWN = 1000
    DIV_CURB = 1
    DIV_FENCE = 2
    DIV_WALL_FLAT = 3
    DIV_WALL_TUNNEL = 4
    DIV_WALL_SOUND = 5
    DIV_JERSEY = 6
    DIV_GUARDRAIL = 7
    DIV_CABLE = 8
    DIV_CLIFF = 9
    DIV_DITCH = 10
    DIV_CRASH_PAD = 11


class ObjectPoleType(Enum):
    """Summary of class here.

    Longer class information....
    Longer class information....

    Attributes:
        likes_spam: A boolean indicating if we like SPAM or not.
        eggs: An integer count of the eggs we have laid.
    """
    POLE_TYPE_UNKNOWN = 1000
    POLE_THICK_SIGN = 1
    POLE_THIN_SIGN = 2
    POLE_LIGHT = 3
    POLE_DIV_BLACK = 4
    POLE_DIV_RED = 5
    POLE_GANTRY = 6
    POLE_BEAR = 7
    POLE_WIRE = 8
    POLE_HORIZONTAL_CAMERA = 8


class ObjectTrafficConeType(Enum):
    """Summary of class here.

    Longer class information....
    Longer class information....

    Attributes:
        likes_spam: A boolean indicating if we like SPAM or not.
        eggs: An integer count of the eggs we have laid.
    """
    TRAFFIC_CONE_TYPE_UNKNOWN = 1000
    TRAFFIC_CONE = 1
    CRASH_BARREL = 2
    WATER_HORSE = 3


class ObjectGantryType(Enum):
    """Summary of class here.

    Longer class information....
    Longer class information....

    Attributes:
        likes_spam: A boolean indicating if we like SPAM or not.
        eggs: An integer count of the eggs we have laid.
    """
    GANTRY_TYPE_UNKNOWN = 1000
    TOP_CAMERA = 1
    TOP_VERTICAL_BRIDGE = 2
    TOP_GANTRY = 3
    TOP_HORIZONTAL_BRIDGE = 4


class IntersectionLocationType(Enum):
    """Summary of class here.

    Longer class information....
    Longer class information....

    Attributes:
        likes_spam: A boolean indicating if we like SPAM or not.
        eggs: An integer count of the eggs we have laid.
    """
    INTERSECTION_LOCATION_UNKNOWN = -1
    ENTRY = 1
    DROP = 2
    ENTRY_AND_DROP = 3


class LaneDirectionType(Enum):
    """Summary of class here.

    Longer class information....
    Longer class information....

    Attributes:
        likes_spam: A boolean indicating if we like SPAM or not.
        eggs: An integer count of the eggs we have laid.
    """
    LANE_DIRECTION_TYPE_UNKNOWN = -1
    ONE_WAY = 1
    TWO_WAY = 2


class LaneNodeType(Enum):
    """Summary of class here.

    Longer class information....
    Longer class information....

    Attributes:
        likes_spam: A boolean indicating if we like SPAM or not.
        eggs: An integer count of the eggs we have laid.
    """
    LANE_NODE_TYPE_UNKNOWN = -1
    LANE_NODE = 1
    TILE_NODE = 2
