"""
S3客户端对外接口
"""
import os


if 'ENV_FOR_DYNACONF' in os.environ and os.environ['ENV_FOR_DYNACONF'] == 'development':
    from datareceiving.core.storage.s3.s3_api_local import S3ClientLocal
    S3Client = S3ClientLocal
else:
    from datareceiving.core.storage.s3.s3_api_remote import S3ClientRemote
    S3Client = S3ClientRemote
