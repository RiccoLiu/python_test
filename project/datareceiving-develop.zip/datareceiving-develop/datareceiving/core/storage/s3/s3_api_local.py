"""
模拟S3客户端
"""
import os
import shutil
from typing import List

from loguru import logger
from datareceiving.common import config
from datareceiving.common import singleton
from datareceiving.core.storage.s3 import s3_api_base


@singleton.Singletons
class S3ClientLocal(s3_api_base.S3ClientBase):
    """
    模拟S3客户端
    """
    def download_file(self, bucket: str, key: str, file_name: str):
        from_file_name = os.path.join(config.Config().config.local.sample,
                                      bucket,
                                      key)
        if not os.path.exists(from_file_name):
            logger.error(f'can not download, {from_file_name} not exists!')
            return
        if os.path.exists(file_name):
            os.remove(file_name)
        path = os.path.dirname(file_name)
        os.makedirs(name=path, exist_ok=True)
        shutil.copy(from_file_name, file_name)

    def upload_file(self, file_name: str, bucket: str, key: str):
        if not os.path.exists(file_name):
            logger.error(f'can not upload, {file_name} not exists!')
            return

        to_file_name = os.path.join(config.Config().config.local.sample,
                                    bucket,
                                    key)
        if os.path.exists(to_file_name):
            os.remove(to_file_name)
        path = os.path.dirname(to_file_name)
        os.makedirs(name=path, exist_ok=True)
        shutil.copy(file_name, to_file_name)
        os.remove(file_name)
        return True

    def file_exists(self, bucket: str, key: str) -> bool:
        file_name = os.path.join(config.Config().config.local.sample,
                                 bucket,
                                 key)
        return os.path.exists(file_name)

    def list_objects(self, bucket: str, prefix: str) -> List[s3_api_base.FileDetail]:
        file_detail_list: List[s3_api_base.FileDetail] = []
        prefix_path = os.path.join(config.Config().config.local.sample,
                                   bucket,
                                   prefix)
        if not os.path.exists(prefix_path):
            logger.error(f'{prefix_path} not exists')
            return file_detail_list

        for dir_path, _, filenames in os.walk(top=prefix_path, topdown=True):
            for filename in filenames:
                key = f'{prefix}{dir_path.split("/")[-1]}/{filename}'
                size = os.path.getsize(os.path.join(dir_path,filename))
                file_detail_list.append(s3_api_base.FileDetail(key, size))
        return file_detail_list

