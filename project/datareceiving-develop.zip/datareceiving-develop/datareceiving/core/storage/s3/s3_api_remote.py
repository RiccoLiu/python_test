"""
实际S3客户端
"""
from typing import List
import minio
from minio import error
from loguru import logger
from datareceiving.common import config
from datareceiving.core.storage.s3 import s3_api_base
from datareceiving.common import singleton


@singleton.Singletons
class S3ClientRemote(s3_api_base.S3ClientBase):
    """
    实际S3客户端
    """

    def __init__(self):
        self.__client = minio.Minio(
            config.Config().config.s3.endpoint_url,  # .secret.common.yaml
            access_key=config.Config().config.s3.aws_access_key_id,
            secret_key=config.Config().config.s3.aws_secret_access_key,
            secure=False)

    def download_file(self, bucket: str, key: str, file_name: str):
        try:
            status = self.__client.download_file(bucket, key, file_name)
        except error.S3Error as exception:
            logger.error(exception)
        if status:
            print(status)

    def upload_file(self, file_name: str, bucket: str, key: str):
        for i in range(5):
            try:
                status = self.__client.fput_object(bucket, key, file_name)
                if status:
                    logger.info('upload file to S3 : ' + status.object_name)
                return True
            except error.S3Error as exception:
                logger.error(exception)
        return False

    def file_exists(self, bucket: str, key: str) -> bool:
        try:
            self.__client.head_object(Bucket=bucket, Key=key)
        except error.S3Error as exception:
            if int(exception.response['Error']['Code']) == 404:
                return False
        return True

    def list_objects(self, bucket: str, prefix: str) -> List[s3_api_base.FileDetail]:
        file_detail_list: List[s3_api_base.FileDetail] = []
        key = prefix.replace('\\', '/')
        if not key.endswith('/'):
            key += '/'
        try:
            objects = self.__client.list_objects(bucket_name=bucket, prefix=key)
            if objects:
                for object_info in objects:
                    file_detail_list.append(s3_api_base.FileDetail(key=object_info.object_name, size=object_info.size))

        except error.S3Error as exception:
            logger.error(exception)

        return file_detail_list
