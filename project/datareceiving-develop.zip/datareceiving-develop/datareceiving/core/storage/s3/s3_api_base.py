"""
S3客户端基类
"""
import abc
from typing import List
from collections import namedtuple

FileDetail = namedtuple('FileDetail', ['key', 'size'])


class S3ClientBase(metaclass=abc.ABCMeta):
    """
    S3客户端基类
    """
    @abc.abstractmethod
    def download_file(self, bucket: str, key: str, file_name: str):
        pass

    @abc.abstractmethod
    def upload_file(self, file_name: str, bucket: str, key: str):
        pass

    @abc.abstractmethod
    def file_exists(self, bucket: str, key: str) -> bool:
        return True

    @abc.abstractmethod
    def list_objects(self, bucket: str, prefix: str) -> List[FileDetail]:
        return []
