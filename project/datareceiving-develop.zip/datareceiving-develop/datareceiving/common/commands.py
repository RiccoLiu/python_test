# -*- coding: UTF-8 -*-
"""注册启动命令.

使用三方库click中的group，各子模块中自定义命令函数及参数，并在business_commands中添加包即可.
"""
import click

from datareceiving.common import config
from datareceiving.core.business.datareceiving import datareceiving  # pylint: disable=unused-import


def register_commands():
    """Register commands.
    Register commands for business
    Args: None
    Returns: None
    Raises: None
    """
    @click.group()
    @click.version_option(version=config.Config().config.app.version)
    def cli():
        pass

    cli.add_command(datareceiving.DataReceiving.data_receiving)
    cli()
