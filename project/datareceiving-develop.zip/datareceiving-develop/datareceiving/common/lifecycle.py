# -*- coding: UTF-8 -*-
"""地图学习子模块流程抽取

BusinessBase实现抽象类中的纯虚函数，继承BusinessBase后，子模块可以根据自己需要实现.

使用示例:

见 BusinessBase
"""
import abc


class Lifecycle(metaclass=abc.ABCMeta):
    """
    抽象类
    抽象地图学习子模块流程
    load -> download -> input -> start -> process -> clear -> output -> upload
    """
    @abc.abstractmethod
    def load(self, *args, **kwargs):
        """
        加载 config 等等.
        """
        pass

    @abc.abstractmethod
    def download(self, *args, **kwargs):
        """
        子模块下载数据
        """
        pass

    @abc.abstractmethod
    def input(self, *args, **kwargs):
        """
        子模块输入处理
        """
        pass

    @abc.abstractmethod
    def start(self, *args, **kwargs):
        """
        process前准备工作
        """
        pass

    @abc.abstractmethod
    def process(self, *args, **kwargs):
        """
        子模块算法处理
        """
        pass

    @abc.abstractmethod
    def clear(self, *args, **kwargs):
        """
        process后清理工作
        """
        pass

    @abc.abstractmethod
    def output(self, *args, **kwargs):
        """
        子模块输出处理
        """
        pass

    @abc.abstractmethod
    def upload(self, *args, **kwargs):
        """
        子模块上传数据
        """
        pass
