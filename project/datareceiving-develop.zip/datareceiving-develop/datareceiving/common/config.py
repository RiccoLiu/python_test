"""
配置读取
"""
import dynaconf
from typing import Optional

from datareceiving.common import singleton
# from datareceiving.common import monitor


@singleton.Singletons
class Config:
    """
    配置读取类（单例）
    """
    def __init__(self):
        self.config: Optional[dynaconf.Dynaconf] = None
        self.load()

    # @monitor.func_time(runtime=True)
    def load(self, name=''):
        """
        load config items only for currently running business
        :return:
        """
        # `envvar_prefix` = export envvars with `export DYNACONF_FOO=bar`.
        # `settings_files` = Load this files in the order.
        if name != '':
            settings_files = ['datareceiving/config/common.yaml',
                              'datareceiving/config/.secret.common.yaml',
                              f'datareceiving/config/{name}.yaml',
                              f'datareceiving/config/.secret.{name}.yaml']
        else:
            settings_files = ['datareceiving/config/common.yaml',
                              'datareceiving/config/.secret.common.yaml']

        self.config = dynaconf.Dynaconf(
            environments=True,
            envvar_prefix='MAPLEARNING',
            settings_files=settings_files,
        )
