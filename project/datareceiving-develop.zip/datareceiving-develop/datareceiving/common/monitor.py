"""
性能统计装饰器
"""
import time
import os
import sys
import threading
import functools
from datetime import datetime
#from datareceiving.common import log


def monitor_log(func, msg):
    t = threading.current_thread()
    pid = os.getpid()

    level_name = 'INFO'
    sub_module = 'ML'
    process = pid
    thread = t.ident
    process_name = 'MainProcess'
    # asc_time = time.strftime("%Y-%m-%d-%H:%M:%S", time.localtime())
    asc_time = datetime.now().strftime('%Y-%m-%d-%H:%M:%S.%f')[:-3]
    filepath = ''
    if func.__module__ in sys.modules:
        filepath = sys.modules[func.__module__].__file__
    line_no = 0
    # msg = ''
    print(f'[{level_name}] {sub_module}({process}:{thread},{process_name}):{asc_time} [{filepath}:{line_no}] {msg}')


def func_time(func=None, runtime=False):
    """
    函数运行时间统计装饰器

    使用示例：
    from maplearning.common import monitor
    @monitor.func_time
    def sample_func():
        pass
    """
    if func is None:
        return functools.partial(func_time, runtime=runtime)

    @functools.wraps(func)
    def wrapper_func(*args, **kwargs):
        start_time = time.perf_counter()
        monitor_log(func, f"{func.__name__}() begin")

        # 调用函数
        ret = func(*args, **kwargs)

        monitor_log(func, f"{func.__name__}() end")
        # 是否显示运行时间，默认否
        if runtime:
            run_time = time.perf_counter() - start_time
            monitor_log(func, f"{func.__name__}() run time: {run_time}s")
        return ret
    return wrapper_func
