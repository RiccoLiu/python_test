"""
单例装饰器
"""


class Singletons(object):
    """
    单例类定义装饰器
    """
    instances = {}

    def __init__(self, cls):
        self.__cls = cls

    def __call__(self, *args, **kwargs):
        if self.__cls not in Singletons.instances:
            Singletons.instances[self.__cls] = self.__cls(*args, **kwargs)
        return Singletons.instances[self.__cls]
