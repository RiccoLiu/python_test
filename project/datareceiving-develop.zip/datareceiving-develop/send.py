# pylint: skip-file
from kafka import KafkaProducer
from time import sleep
from datareceiving.common import config

def start_producer():
    c = config.Config()
    c.load(name='data-receiving')
    host = c.config.host
    port = c.config.port
    print(host, port)
    producer = KafkaProducer(bootstrap_servers=f'{host}:{port}',
                             api_version=(0, 10))

    for i in range(0,10):
        print(f'before {i}:')
        file = './slam_location.record.bin'
        with open(file, 'rb') as f:
            con = f.read()
        print(f'before send {i}:')
        #已经是二进制信息，否则需要转换成二进制信息，con.encode('utf-8')
        key = b'0_0_1649727258448_1_7456444838d15708928e8f558948ec36'
        producer.send('topic.collection', con,key)

        # print(con)
        sleep(0.5)
        print(i)

        # print(msg)
    # for i in range(10, 20):
    #     msg = 'msg is ' + str(i)
    #     producer.send('my_favorite_topic2', msg.encode('utf-8'))
    #     sleep(3)


if __name__ == '__main__':
    start_producer()